import sqlite3

conn = sqlite3.connect("nailstudio.db")

conn.execute("""
CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    service TEXT NOT NULL
);
""")

conn.close()

print("Database created successfully!")
