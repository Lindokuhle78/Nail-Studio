from flask import Flask, render_template, request, redirect, flash
import sqlite3

app = Flask(__name__)
app.secret_key = "nailstudio_secret"

def get_db():
    conn = sqlite3.connect("nailstudio.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/booking", methods=["GET", "POST"])
def booking():
    if request.method == "POST":
        name = request.form["name"].strip()
        phone = request.form["phone"].strip()
        service = request.form["service"]

        if not name or not phone:
            flash("All fields are required.")
            return redirect("/booking")

        conn = get_db()
        conn.execute(
            "INSERT INTO bookings (name, phone, service) VALUES (?, ?, ?)",
            (name, phone, service)
        )
        conn.commit()
        conn.close()

        flash("Appointment booked successfully!")
        return redirect("/appointments")

    return render_template("booking.html")

@app.route("/appointments")
def appointments():
    conn = get_db()
    rows = conn.execute("SELECT * FROM bookings ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("appointments.html", rows=rows)

if __name__ == "__main__":
    app.run(debug=True)
